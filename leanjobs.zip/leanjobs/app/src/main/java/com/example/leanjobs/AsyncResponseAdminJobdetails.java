package com.example.leanjobs;

public interface AsyncResponseAdminJobdetails {
    void processFinishAdminJobDetails(Job job);
}
