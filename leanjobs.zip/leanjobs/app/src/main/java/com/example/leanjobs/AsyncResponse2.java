package com.example.leanjobs;

public interface AsyncResponse2 {
        void processFinish2(Job job);
    }
