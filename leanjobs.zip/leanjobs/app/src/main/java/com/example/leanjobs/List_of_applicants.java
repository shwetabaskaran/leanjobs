package com.example.leanjobs;

import android.app.ListActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class List_of_applicants extends ListActivity implements AsyncResponse3 {
    public int id = 8;
    public int page = 0;
    ApplicantsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_applicants);
    }

    @Override
    public void processFinished(final ArrayList<Applicant> applicants) {

        adapter = new ApplicantsAdapter(this, applicants);
        setListAdapter(adapter);

        if (applicants.size() > 0) {
            ListView listView = getListView();
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View itemClicked, int position, long id) {
                    Applicant selectedApplicant  = applicants.get(position);
                    Intent intent = new Intent(List_of_applicants.this, ApplicantDetails.class);
                    intent.putExtra("applicantid", selectedApplicant.getApplicantID());
                    startActivity(intent);
                }
            });
        }
    }

    public void onResume(){
        super.onResume();
        LongRunningGetIO asyncTask =new LongRunningGetIO();
        asyncTask.delegate = this; //
        asyncTask.execute();
    }
}}

class LongRunningGetIOO extends AsyncTask<Void, Void, String> {

    public AsyncResponse3 delegate = null;
    List_of_applicants obj = new List_of_applicants();

    protected String getASCIIContentFromEntity(HttpEntity entity) throws IllegalStateException, IOException {
        InputStream in = entity.getContent();
        StringBuffer out = new StringBuffer();
        int n = 1;
        while (n > 0) {
            byte[] b = new byte[4096];
            n = in.read(b);
            if (n > 0) out.append(new String(b, 0, n));
        }
        return out.toString();
    }

    @Override
    protected String doInBackground(Void... params) {
        HttpClient httpClient = new DefaultHttpClient();
        HttpContext localContext = new BasicHttpContext();
        String url = "http://dhillonds.com/leanjobsweb/index.php/api/jobs/list_user?page="+obj.page+"&user_id="+obj.id;
        HttpGet httpGet = new HttpGet(url);
        String text = null;
        try {
            HttpResponse response = httpClient.execute(httpGet, localContext);
            HttpEntity entity = response.getEntity();
            text = getASCIIContentFromEntity(entity);
        } catch (Exception e) {
            return e.getLocalizedMessage();
        }
        return text;
    }

    protected void onPostExecute(String results) {
        if (results != null) {
            ArrayList<Applicant> applicantlist = new ArrayList<Applicant>();

            try {
                JSONObject jobj=new JSONObject(results);
                String c = jobj.getString("data");
                JSONArray applicants = new JSONArray(c);

                for(int i = 0; i<applicants.length(); i++) {
                    Applicant joba = new Applicant();
                    int jobid = applicants.getJSONObject(i).getInt("applicant_id");
                    String jname = applicants.getJSONObject(i).getString("title");

                    joba.setApplicantID(jobid);
                    joba.setApplicantName(jname);

                    applicantlist.add(joba);
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }

            delegate.processFinished(applicantlist);
        }
    }
}
