package com.example.leanjobs;

public class Applicant {



    private int applicantID;
    private String applicantName;
   /* private String jobRoleDesc;
    private String jobReqs;
    private String jobWages;
    private int jobIsActive;
    private String jobCreatedAt;*/

    public Applicant(){}

    public int getApplicantID() {
        return applicantID;
    }
    public void setApplicantID(int i) {
        applicantID = i;
    }

    public String getApplicantName() {
        return getApplicantName();
    }
    public void setApplicantName(String s) {
        applicantName = s;
    }
/*
    public String getJobRoleDesc() {
        return jobRoleDesc;
    }
    public void setJobRoleDesc(String s) {
        jobRoleDesc = s;
    }

    public String getjobReqs() {
        return jobReqs;
    }
    public void setJobReqs(String s) {
        jobReqs = s;
    }

    public String getJobWages() {
        return jobWages;
    }
    public void setJobWages(String s) {
        jobWages = s;
    }

    public int getJobIsActive() {
        return jobIsActive;
    }
    public void setJobIsActive(int s) {
        jobIsActive = s;
    }

    public String getJobCreatedAt() {
        return jobCreatedAt;
    }
    public void setJobCreatedAt(String s) {
        jobWages = s;
    }*/

}
