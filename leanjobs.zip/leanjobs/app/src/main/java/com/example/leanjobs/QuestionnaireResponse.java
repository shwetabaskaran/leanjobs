package com.example.leanjobs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class QuestionnaireResponse extends AppCompatActivity {
    //Write Loginc for Dynamic list of cards https://javapapers.com/android/android-cards-list-view/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire_response);
    }
}
