package com.example.leanjobs;

public class Wrapper
{
    public String results;
    public int jobid;
    String jobtitle;
}