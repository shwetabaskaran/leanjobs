package com.example.leanjobs;

import java.util.ArrayList;

public interface AsyncResponseAdminJoblist {
    void processFinishAdminJobList(ArrayList<Job> output);
}
